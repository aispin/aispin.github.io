# 清理与文档 · 交付说明（2026-10-07）

对应你那条多段指令里的 1.1–1.5、2、3、4，以及 profile 项目迁移盘点。
bug 修复与新特性（问题 1–4、新特性 1–4）**不在本轮**，见文末。

---

## A. 清理结果（1.1–1.5）

| # | 你的要求 | 结果 |
|---|---|---|
| 1.1 | demos 目录保留，构建时扫描生成 index + json | ✅ `scripts/build-demos-index.mjs`，已接进 `vite.config.js` 的 `buildStart` |
| 1.2 | 移除 `public/start/`；新增 `/me` 独立页 | ✅ `/start` 已删（上一轮），`/me` 本轮新建并跑通 |
| 1.3 | 移除概念图 / 独立美术页 | ✅ `public/art/`、`art/` 已删（上一轮，已归档） |
| 1.4 | 移除 | ✅ 已删（上一轮） |
| 1.5 | 移除 | ✅ 已删（上一轮） |
| 2 | 哪些需要构建时更新 | ✅ 见本文 §B |
| 3 | README 更新 / LICENSE 加署名 / .gitignore 评估 | ✅ 上一轮完成，本轮补齐 `/me` 与 demos 章节 |
| 4 | 删死字体、保留 `maple-ui.woff`、确认是否按 i18n 打包 | ✅ 见 §D |
| — | profile 项目迁移清单 | ✅ 见 §C |

### 本轮新增/修改的文件

**新增**

| 文件 | 说明 |
|---|---|
| `me/index.html` | `/me` 的 HTML entry |
| `src/me/meData.js` | 把 `me.json` + `profile/site/projects/music/aiProjects.json` 装配成页面模型 |
| `src/me/main.js` | 渲染 + 接线（主题、语言、倾斜、滚动进场） |
| `src/me/me.css` | 设计变量与全部样式（含暗色） |
| `src/me/fluidBg.js` | 全屏 WebGL 流体背景（原生 GLSL，**不引 three**） |
| `src/me/player.js` | 程序化氛围曲播放器 + canvas 节拍可视化 |
| `src/data/me.json` | `/me` 的编辑性文案 |

**修改**

| 文件 | 改了什么 |
|---|---|
| `vite.config.js` | 多页 entry（`index.html` + `me/index.html`）；`/me` 重写；**`public/` 目录 URL 重写**；`buildStart` 调 demos 索引；`manualChunks` 不变 |
| `scripts/build-demos-index.mjs` | 抽成 `export function buildDemosIndex()`，保留直接执行入口 |
| `seo-plugin.js` | `transformIndexHtml` 加 entry 守卫 —— 否则主站的 title/JSON-LD 会覆盖 `/me` |
| `public/_redirects` | `/start` → `/me`；顺带清掉波兰语注释 |
| `src/styles/GlobalOverlay.scss` | 删掉 `'Fredericka the Great'` 的 `@font-face`（零引用） |
| `README.md` | 新增「两个入口」「随手放的原型」章节；修掉 i18n 的过期说明 |

**删除（均已归档到 `.workbuddy-ai/*.tar.gz`）**

| 目标 | 归档 | 理由 |
|---|---|---|
| `public/fonts/FrederickatheGreat-Regular.ttf`（485 KB） | `removed-dead-font-20261007-154524.tar.gz` | 声明了 `@font-face`，但全仓库零处使用该 family |
| `src/i18n/zh-CN.json` · `en-US.json`（7.8 KB） | `removed-dead-i18n-20261007-155901.tar.gz` | 没有任何代码 import / glob / fetch 它们 —— 改了不生效的陷阱 |

---

## B. 哪些内容需要「构建时更新」

### B1. 构建时**自动**跑（不用管，但要知道它会发生）

| 产物 | 由谁生成 | 时机 |
|---|---|---|
| `public/demos/demos.json` | `scripts/build-demos-index.mjs` | `buildStart`（build + dev 启动都会跑） |
| `public/demos/index.html` | 同上 | 同上 |
| `public/demos/*/README.md` | 同上 | 该目录**缺** README 时才补，不覆盖已存在的 |
| `dist/404.html` | `vite.config.js` → `emit404Fallback` | `closeBundle` |
| `dist/llms.txt` | `seo-plugin.js` | `generateBundle` |
| `index.html` 的 `<title>` / `description` / JSON-LD | `seo-plugin.js` | `transformIndexHtml`（**只对主站 entry**） |
| `/llms.txt`（dev 下按需生成） | `seo-plugin.js` | dev 中间件 |
| `dist/assets/*.js.gz` · `*.css.gz` | `vite-plugin-compression` | build |

> ⚠️ 因为 demos 索引写在 `public/` 里、又在 `buildStart` 生成，所以**它必须在 Vite
> 把 `public/` 拷进 `dist` 之前跑完**。这是把它挂在 `buildStart` 而不是
> npm script 里的原因。

### B2. 需要**手动**跑脚本（构建时更新，但有触发条件）

| 产物 | 脚本 | 什么时候必须跑 |
|---|---|---|
| `public/fonts/maple-ui.woff` · `maple-ui.woff2` | `python3 scripts/build-scene-fonts.py` | **改了 `src/` 下任何面向用户的文案之后**（`data/*.json`、`config/theme.js`、组件里的中文字面量）。少一个字，troika 就会去够 CDN，整个 3D 场景挂住 |
| `src/data/aiProjects.json` | `node scripts/refresh-ai-projects.mjs` | 想同步 GitHub 上的 `iskill-*` / `ai-*` 仓库时。**已有 GitHub Actions 每周一自动跑并提交**（`.github/workflows/refresh-ai-projects.yml`） |

### B3. 不需要构建 —— 改完直接生效（生产环境仍需重新部署）

`public/` 下的纯静态资源是**原样拷贝**进 `dist/` 的，不经过打包：
`fonts/`、`sounds/`、`textures/`、`articles/*.webp`、`og-image.webp`、
`favicon.svg`、`app-icon-maskable.svg`、`robots.txt`、`sitemap.xml`、
`manifest.webmanifest`、`_headers`、`_redirects`、`.nojekyll`、`demos/`（除生成物）。

**例外**：`public/sw.js` 虽然也是原样拷贝，但改了缓存策略要**同时改 `VERSION`**
（现在是 `aispin-v5`），否则老访客的 SW 不会更新。

### B4. 不进构建、也不该进仓库

- `.workbuddy-ai/` —— 已在 `.gitignore` 里。里面是本机强相关的归档、无头验证
  harness、截图，以及 agent 的长期记忆。

---

## C. profile 项目迁移清单

`/Volumes/Pluto/dev/github/aispin/profile` 现在总共只有 **3 项**内容（10 MB）：

### ✅ 已迁移

| 内容 | 迁到哪 | 状态 |
|---|---|---|
| `.workbuddy-ai/memory/`（6 个文件，224 KB）<br>`2026-10-03.md` `04` `05` `06` `07` `MEMORY.md` | `aispin.github.io/.workbuddy-ai/memory/` | **已完整复制**，6 个文件的字节数与修改时间逐一核对一致。目标目录里原本已有的旧版本另存为 `*.snapshot-1004.md`，没有覆盖 |

### ❌ 未迁移 —— 且**建议不迁**

| 内容 | 大小 | 为什么不用迁 |
|---|---|---|
| `generated-images/` 4 张 PNG | 9.9 MB | 全名是 `Colorize_this_hand_drawn_{brick,stone,tree,cat_s}_*.png`，是早期「给手绘稿上色」的 ImageGen 参考图。**全仓库零引用**（已用全文扫描确认）。而且本项目已定为**零 jpg/png + 全程序化**，这 4 张恰好违反该约定，迁进来就是新的死资产 |
| `README-会话占位.txt` | 215 B | 自述是占位文件，内容无价值 |

### ⚠️ 删之前必须知道的一件事

**这个目录现在是当前 WorkBuddy 会话的 shell 工作目录，同时也是 agent
工作区记忆（`.workbuddy-ai/memory/`）的落盘位置。**

- `README-会话占位.txt` 里写明：「删除本目录会导致本会话无法执行命令」
- 系统侧的工作区记忆路径仍然指向 `profile/.workbuddy-ai/memory/`，
  也就是说**本轮之后的记忆写入仍然写在 profile 里**，不是写在 app 项目里

所以：

1. 内容价值上，profile **可以删** —— 唯一有价值的记忆已经镜像到 app 项目了；
2. 但**现在删会立刻打断这个会话**，并且新记忆会失去落点；
3. 建议顺序：**先切到 app 项目目录**（让工作区指向
   `aispin.github.io/.workbuddy-ai/memory/`）→ 确认新会话的记忆落在 app 项目里
   → 再删 profile。

如果你希望「现在就删」，我可以把 app 项目的记忆目录当作唯一副本继续用，
但需要你确认接受「本会话的 shell 会失效、要重开会话」这个代价。

---

## D. 字体审计（问题 4）

### 结论：**不是按 i18n 打包的**，是按 `src/` 全量字符集打包的 —— 这是刻意的

`scripts/build-scene-fonts.py` 扫的是 **`src/` 下出现的每一个字符**，
不是某个 i18n key 集合。原因写在脚本和 `theme.js` 的注释里：

> troika（drei 的 `<Text>`）只认 ttf/otf/woff，**不认 woff2**；
> 而它一旦缺字，会回退到 `cdn.jsdelivr.net` 的 unicode-font-resolver ——
> 这个 CDN 在国内/离线不可达，promise 被拒后 `<Text>` 永远不同步，
> **整个 R3F 场景会一起挂住**。所以宁可大一点也不能缺字。

曾经有过一个「按最小场景字符集裁剪」的版本（`scripts/build-font-subset.py`
→ `maple-3d.woff`），那正是上面那个崩溃的成因，已删除。

### `public/fonts/` 现状（4 个文件，1.28 MB）

| 文件 | 大小 | 声明处 | 实际使用 | 判定 |
|---|---|---|---|---|
| `maple-ui.woff` | 486 KB | `styles/_fonts.scss`（`MapleUI` 兜底）+ `theme.js font3d` | DOM 的 `MapleUI` **和** 3D 场景文字 | **保留（核心）** |
| `maple-ui.woff2` | 367 KB | `styles/_fonts.scss`（首选） | DOM | **保留** |
| `CabinSketch-Bold.ttf` | 269 KB | `GlobalOverlay.scss` | DOM：`GlobalOverlay.jsx`（标题）、`NavigationUI.scss`；3D：`EntranceDoors` / `SignSystem` / `DoorSection`（门牌） | **保留（活）** |
| `CabinSketch-Regular.ttf` | 155 KB | `GlobalOverlay.scss` | 3D：`CorridorDecorations.jsx:47` 画框说明 | **保留（活）** |
| `RubikScribble-Regular.ttf` | 584 KB | `GlobalOverlay.scss` | DOM：`GlobalOverlay.jsx:394,470`、`GlobalOverlay.scss:140` | **保留（活）** |
| ~~`FrederickatheGreat-Regular.ttf`~~ | ~~485 KB~~ | ~~`GlobalOverlay.scss`~~ | **零引用** | **已删** |
| ~~`maple-cn.woff`~~ | ~~486 KB~~ | — | 与 `maple-ui.woff` **逐字节相同**的重复品 | 上一轮已删 |
| ~~`maple-3d.woff`~~ | ~~72 KB~~ | — | 旧的最小场景子集，CDN 崩溃成因 | 上一轮已删 |

**所以「删除死字体」实际只删得掉 1 个文件**：Fredericka。
另外三个手写体不是遗留素材，是活的门牌/画框字体 —— 删了门牌上的
`ARCHIVE` / `CONTACT` 会掉字形。

如果你要的是**只留 Maple 一套**（把门牌、画框也改成 Maple），
那是另一个决定：说一声，我把 `SCENE_FONTS.cabin*` 的引用点改掉，
再删这三个 TTF，能省 1 MB。

---

## E. `/me` 页面

### 怎么访问

- dev：`http://localhost:5199/me`（不带尾斜杠也认）
- 生产：`https://aispin.github.io/me/`

### 它是什么

原型 `public/demos/web3d/3d-ip-landing/index.html`（Hugo 的占位身份）的
**数据驱动版**：结构、配色、WebGL 背景、卡片倾斜、滚动进场全部沿用，
但页面上没有一条内容是写死在 HTML 里的。

| 区块 | 数据来源 |
|---|---|
| 姓名 / 位置 | `profile.json` |
| 三种身份 + 标签 | `me.json`（文案）+ `profile.skills` |
| 作品三张卡 | `me.json` 里写 `projectId` → `projects.json` 取真项目 |
| 曲目列表 | `music.json`（6 首，链到网易云） |
| 联系方式 | `profile.email` / `github` |
| 页脚统计 | `aiProjects.json` / `music.json` / `projects.json` 的真实条数 |
| 背景音 | `src/audio/bgm.js`（仓库里已有的生成式 BGM 引擎，零素材） |

### 与主站的联动

共用 `localStorage` 的 `aispin-theme` / `aispin-language`，
所以在 3D 房子里切到夜间模式、切到英文，再打开 `/me` 是接着的。
`/me` 上也有自己的主题 / 语言切换按钮，改回去同样影响主站。

### 验证记录

| 项 | 结果 |
|---|---|
| 渲染（明/暗 × 中/英） | 3 身份卡 + 3 作品卡 + 6 曲目 + 3 联系入口 + 3 统计，全部就位 |
| 控制台 | **0 错误、0 失败请求** |
| 音频 | 手势前 0 个 `AudioContext`；点击后 `state=running`；**RMS 0.0325**（> 0.0005 判据）；暂停后 RMS 回 0；`started=3 / stopped=3 / live=0` 无泄漏；无 autoplay 警告 |
| 打包体积 | me chunk **20 KB**、CSS 17 KB、共享数据 chunk 71 KB（gzip 合计 ~39 KB），**不含 three** |
| 生产构建 | `dist/me/index.html` 生成，preview 下 `/me` 与 `/me/` 均 200 且标题正确 |
| 3D 主站回归 | 716 meshes / 647 materials / 0 错误 —— 与改动前一致 |

### 顺手修掉的一个 dev-only bug

`public/` 下的目录 URL（`/demos/`、`/demos/web3d/3d-ip-landing/`）在 **dev 下
打开的是 3D 主站**，生产环境却是对的。

原因：Vite 用 sirv 提供 `public/`，配置是 `extensions: []`，**不会**把
`/demos/foo/` 解析成 `/demos/foo/index.html`；请求落空后继续往后走，
被 `appType:'spa'` 的 htmlFallback 重写成了主站 `index.html`。
已在 `vite.config.js` 加 `rewritePublicDirIndex` 消掉这个差异
（带目录穿越防护）。

---

## F. 没做的部分（等你一句话）

按你说的「清理与文档后，提及一次。再修 bug 和做新特性」，
下面这些**本轮没动**：

**问题**
1. 门周围白边（门楣上方尤为明显）
2. 小狗 / 柿子的比例（要按真实尺寸算一遍）
3. 屋内人物动作改为缓慢招手；窗口人物、招手 IP 图（已获准用 ImageGen 只做人）
4. 外墙竹影 → 从下往上的藤蔓（柿子树另一侧）

**新特性**
1. 对联按 12 节气 + 传统节日动态变换（先出文案给你审）
2. ZEO STUDIO 横木右边挂一盏灯
3. 窗帘优化（现在不像窗帘）
4. 夜间模式 19:00–05:00（狗躺睡、兔睡、萤火虫、横木灯亮，以及屋内其他表现）
