# 与 3D 应用无关的文件清单

盘点日期：2026-10-07
方法：**去注释的引用扫描**（候选 = `public/**` + `art/**` + `scripts/**`；
引用源 = `src/**` + `index.html` + `vite.config.js` + `seo-plugin.js` + `package.json` + `public/**` 自身）

> 三个必须的细节，否则会误判：
> 1. **先剥注释** —— 否则 `theme.js` 里一句 `Regenerate with: python3 scripts/build-scene-fonts.py`
>    会让那个脚本看起来「被引用」。
> 2. **用词边界** —— 否则 `maple-ui.woff` 会命中 `maple-ui.woff2`。
> 3. **`index.html` 只认 URL 路径，不认裸文件名** —— `vite.config.js` 的 404 兜底里有
>    `resolve(outDir, 'index.html')`，会让所有 `**/index.html` 误判成「被引用」。

---

## 0. 本轮已删除

| 路径 | 体积 |
|---|---|
| `.workbuddy-ai/dist-old-*`（6 个） | **56.2 MB** |

都是可随时用 `vite build` 重建的历史构建快照。删前已确认当前 `dist`（14:32，含树结修复）
是最新的。`.workbuddy-ai` 从 229M → 170M。

---

## 1. 完全无关，可直接删（约 1.9 MB / 50 个文件）

⚠️ 这些**目前都在被公开部署** —— `dist` 共 113 个文件，其中 `demos/` 就占 41 个。

### 1.1 别处的演示页 / 素材 —— `public/demos/`（468K）

| 路径 | 说明 |
|---|---|
| `public/demos/skill-ui/SKILL.md`、`README.md` | 某个 skill 的文档 |
| `public/demos/skill-ui/examples/01-landing.html` | skill UI 演示页 |
| `public/demos/skill-ui/examples/02-dashboard.html` | 同上 |
| `public/demos/skill-ui/examples/03-desktop-app.html` | 同上 |
| `public/demos/skill-ui/examples/04-settings.html` | 同上 |
| `public/demos/skill-ui/examples/05-state-gallery.html` | 同上 |
| `public/demos/skill-ui/examples/06-3d-personal-ip.html` | 同上 |
| `public/demos/web3d/old-house/index.html` | 另一个 3D demo（老房子） |
| `public/demos/web3d/old-house/index-a.html` | 同上（A 版） |
| `public/demos/web3d/old-house/index-b.html` | 同上（B 版） |
| `public/demos/web3d/old-house/tree.html` | 同上（树） |
| `public/demos/web3d/old-house/oldhouse.svg` | 同上素材 |
| `public/demos/web3d/old-house/readme.md` | 同上文档 |
| `public/demos/web3d/rainy-night/index.html` | 另一个 3D demo（雨夜） |
| `public/demos/web3d/life-meaning/index.html` | 另一个 3D demo |
| `public/demos/web3d/web3d-basic.svg` | 同上素材 |
| `public/demos/web3d/.DS_Store` | macOS 垃圾 |
| `public/demos/avatar/ai-matrix-logo.svg` | 别处的头像素材 |
| `public/demos/avatar/boy-00.svg` … `boy-04.svg`（5 个） | 同上 |
| `public/demos/avatar/girl-01.svg` … `girl-03.svg`（3 个） | 同上 |

> **例外，别删**：`public/demos/door.html` —— 它是程序化门美术的**参考稿**，
> `src/utils/gateArt.js` 的注释写明这些纹样是「the vector artwork of the reference
> mock-up (public/demos/door.html) replayed through Path2D」。删了就没法回溯门纹样怎么来的。

### 1.2 独立落地页 —— `public/start/`（916K）

`index.html`、`script.js`、`style.css`、`ip-character.webp`、
`fonts/barlow-condensed-700-latin.woff2`、`fonts/OFL.txt`、
`vendor/{ip-scene.js, three.module.min.js, three.core.min.js, THREE-LICENSE.txt}`

> ⚠️ **状态特殊：故意接线，但没人进得去。**
> `vite.config.js` 里有 `START_PAGE_PATHS` 重写规则（`/start` → `/start/index.html`），
> `scripts/test-start.mjs` 也在测它；但 **`src/` 里没有任何链接指向 `/start`**。
> 所以它不是「忘了删」，而是「做了一半的入口」—— 要么接个入口进去，要么整块撤掉。

### 1.3 概念图 / 独立美术页（204K）

| 路径 | 说明 |
|---|---|
| `public/art/door-sign.webp` | 门牌概念图，已被程序化美术取代 |
| `public/art/room-about-concept.webp` | about 房间概念图，同上 |
| `art/index.html` | 32K 的独立美术展示页，**连 dist 都进不去**（不在 `public/` 下） |

### 1.4 脚手架残留 / 系统垃圾

| 路径 | 说明 |
|---|---|
| `public/vite.svg` | Vite 脚手架默认 logo |
| `..gitignore.xEKyn35paY` | macOS「删除临时名」残留（`.<原名>.<随机串>`），内容与 `.gitignore` 逐字节相同 |

### 1.5 已废弃的构建脚本

| 脚本 | 为什么废弃 |
|---|---|
| `scripts/generate-guitar-cursors.py` | 吉他光标已改为**程序化像素画** |
| `scripts/generate-pwa-icons.py` | favicon / PWA 图标已改为 **SVG + 运行时 canvas** |
| `scripts/redraw-door-stickers.py` | 门贴纸已**移除**，改为程序化音乐/AI/Code 图标 |
| `scripts/redraw-sign-zeohouse.py` | 招牌已改为 **ZEO STUDIO** 且程序化绘制 |

---

## 2. 不属于 3D 应用本体，但是站点基础设施（建议保留）

| 路径 | 说明 |
|---|---|
| `public/.nojekyll` | GitHub Pages 必需（否则下划线开头的文件不发布） |
| `public/_headers` | Cloudflare Pages 响应头配置 |
| `public/_redirects` | 重定向规则 |
| `public/robots.txt` | 爬虫规则 |
| `public/sitemap.xml` | 站点地图（`robots.txt` 引用它） |
| `public/start/fonts/OFL.txt`、`public/start/vendor/THREE-LICENSE.txt` | 许可证，随 `start/` 一起处置 |

## 3. 不是应用运行时，但是仓库 / 工程配置

| 路径 | 说明 |
|---|---|
| `README.md`、`TODO.md`、`LICENSE` | **上游开源仓库**的文件（README 自称是 "Tomasz ITom Szmajda's …" 的仓库） |
| `.github/**` | PR / issue 模板、dependabot、deploy workflow |
| `.agent/**` | agent 配置（`PROJECT.md` + `skills/`） |
| `.workbuddy-ai/**` | agent 工作区（备份 / harness / 截图） |
| `eslint.config.js`、`vite.config.js`、`package.json` | 工程配置（**在用**） |
| `seo-plugin.js` | **在用** —— 生成 `dist/llms.txt` |

---

## 4. 🔴 顺带查出两个真问题（是浪费，不是「无关文件」）

### 4.1 `public/fonts/maple-3d.woff`（72 KB）是**死字体**

全库唯一引用它的地方是 `public/sw.js` 的**预缓存清单**：

```js
'/fonts/maple-ui.woff2',
'/fonts/maple-ui.woff',
'/fonts/maple-3d.woff',     // ← 只有这里
```

也就是说 **每次 PWA 安装都会下载这 72 KB，而没有任何代码使用它**。
（`src/config/theme.js` 的 `font3d` 指向的是 `maple-cn.woff`，不是它。）

**处理**：从 `sw.js` 的预缓存清单里删掉这一行；确认无引用后删除文件。

### 4.2 `maple-cn.woff` 与 `maple-ui.woff` **逐字节相同**

```
MD5 (maple-cn.woff) = 11e59b3bac6f7941adf0f6590cb07956
MD5 (maple-ui.woff) = 11e59b3bac6f7941adf0f6590cb07956
```

各 486 KB。两个不同 URL → 浏览器缓存里存两份。
（这正是遗留任务 #88「删重复字体 maple-cn.woff」要处理的。）

**处理**：让 `theme.js` 的 `font3d` 直接指向 `/fonts/maple-ui.woff`，删掉 `maple-cn.woff`。

---

## 5. 确认属于应用本体（别动）

`index.html`、`src/**`、
`public/fonts/{maple-ui.woff,maple-ui.woff2,CabinSketch-*,FrederickatheGreat-*,RubikScribble-*}`、
`public/sounds/**`、`public/textures/corridor/avatar_zeo.webp`、`public/articles/**`、
`public/sw.js`、`public/manifest.webmanifest`、`public/favicon.svg`、
`public/app-icon-maskable.svg`、`public/og-image.webp`、
`scripts/{build-font-subset.py, build-scene-fonts.py, refresh-ai-projects.mjs, test-start.mjs}`

> `scripts/refresh-ai-projects.mjs` 会从 GitHub API 拉公开仓库写进
> `src/data/aiProjects.json` —— 它维护的是**应用数据**，不是一次性的。
